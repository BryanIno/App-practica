<header>
    <nav class="navbar navbar-danger bg-danger shadow-lg ">
        <ul class="list-inline ">
            <li class="h1 list-inline-item mx-5 ">
                <a class="text-white nav-link " href="{{route('home')}}"> Inicio</a>
            </li>
            <li class="h1 list-inline-item mx-5">
                <a class="text-white nav-link" href="{{route('user.index')}}">Registro de Usuarios</a>
            </li>
            <li class="h1 list-inline-item mx-5" >
                <a class="text-white nav-link" href="{{route('user.grafico')}}" >Grafico de Usuarios</a>
            </li>
        </ul>
    </nav>
</header>

