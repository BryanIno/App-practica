@extends('layouts.layouts')
@section('contenido')
    <h1 class="text-center">
        Bienvenido a la App
    </h1>
@endsection