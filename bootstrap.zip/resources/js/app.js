import './bootstrap';
window.Swal = require('sweetalert2')
