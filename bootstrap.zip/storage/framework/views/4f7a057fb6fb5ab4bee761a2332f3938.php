
<?php $__env->startSection('titulo','Ver Usuario'); ?>

<?php $__env->startSection('contenido'); ?>
    <h1 class="text-center">
        Bienvenido <?php echo e($user->name); ?>

    </h1>
    <div class="text-center">
        <p class="h6">
            Nombre de Usuario: <?php echo e($user->name); ?>

        </p>
        <p class="h6">
            Correo Electronico: <?php echo e($user->email); ?>

        </p>
        
        <a href="<?php echo e(route('user.edit',$user)); ?>" class="btn btn-success">Editar</a>
        <a href="<?php echo e(route('user.index')); ?>" class="btn btn-secondary">Regresar a la pagina anterior</a>
    </div>
    
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\app-practica\resources\views/usuarios/show.blade.php ENDPATH**/ ?>