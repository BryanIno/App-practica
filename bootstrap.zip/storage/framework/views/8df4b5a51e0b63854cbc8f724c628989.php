<?php $__env->startSection('contenido'); ?>
    <h1 class="text-center">
        Bienvenido a la App
    </h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\app-practica\resources\views/welcome.blade.php ENDPATH**/ ?>