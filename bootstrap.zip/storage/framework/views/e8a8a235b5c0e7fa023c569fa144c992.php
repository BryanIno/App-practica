

<?php $__env->startSection('contenido'); ?>

<h1 class="text-center mt-3">Graficos de Usuarios</h1>

<div class="container mb-3">
    <div class="row">
        <div class="col shadow">
            <div class="card">
                <!--<div class="card-header">Usuarios creados en el Mes</div> -->

                <div class="card-body">

                    <h1><?php echo e($chart->options['chart_title']); ?></h1>
                    <?php echo $chart->renderHtml(); ?>

                    
                </div>
            </div>

        </div>
        <div class="col shadow">
            <div class="card">
                <!--<div class="card-header">Usuarios creados en el Mes</div> -->

                <div class="card-body">

                    <h1><?php echo e($chart2->options['chart_title']); ?></h1>
                    <?php echo $chart2->renderHtml(); ?>


                </div>

            </div>
        </div>
    </div>
</div>

    
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('grafico'); ?>
    <?php echo $chart->renderChartJsLibrary(); ?>

    <?php echo $chart->renderJs(); ?>

    <?php echo $chart2->renderJs(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\app-practica\resources\views/usuarios/grafico.blade.php ENDPATH**/ ?>