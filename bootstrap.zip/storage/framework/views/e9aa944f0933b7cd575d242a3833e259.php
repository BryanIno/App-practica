
<?php $__env->startSection('titulo','Editar Usuario'); ?>

<?php $__env->startSection('contenido'); ?>
    <h1 class="text-center">
        Editar usuarios
    </h1>

    <form action="<?php echo e(route('user.update',$user)); ?>" method="post" class="text-center">
        <?php echo csrf_field(); ?>
        <?php echo method_field('put'); ?>
        <label for="nombre" class="form-label">
            Nombre de Usuario:
            <input class="form-control" type="text" name="nombre" id="nombre" value="<?php echo e($user->name); ?>">
            <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <!--Acá recibimos el error de la validación del request -->
                    <small>*<?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </label>
        <br>
        <label for="correo" class="form-label">
            Correo Electronico:
            <input class="form-control" type="email" name="correo" id="correo" value="<?php echo e($user->email); ?>">
            <?php $__errorArgs = ['correo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small>*<?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </label>
        <br>
        <label for="contraseña" class="form-label">
            Contraseña:
            <input class="form-control" type="password" name="contraseña" id="contraseña" value="">
            <?php $__errorArgs = ['contraseña'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small>*<?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </label>
        <br>
        <label class="form-label">
            <button class="btn btn-success" type="submit">
                Guardar
            </button>
         </label>
        <a href="<?php echo e(route('user.index')); ?>" class="btn btn-secondary">Cancelar</a>
        
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\app-practica\resources\views/usuarios/edit.blade.php ENDPATH**/ ?>