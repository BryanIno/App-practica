
<?php $__env->startSection('titulo','Crear Usuario'); ?>

<?php $__env->startSection('contenido'); ?>
    <h1 class="text-center">
        Registrar
    </h1>
   
    <form action="<?php echo e(route('user.store')); ?>" method="post" class="text-center crear">
        <?php echo csrf_field(); ?>
        <label class="form-label" for="nombre">
            Nombre de Usuario
            <input class="form-control shadow" type="text" name="nombre" id="nombre" placeholder="Juan Perez" value="<?php echo e(old('nombre')); ?>">
            <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small>*<?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </label>
        
        <br>
        
        <label class="form-label " for="correo">
            Correo Electronico
            <input class="form-control shadow" type="email" name="correo" id="correo" placeholder="nombre@dominio.com" value="<?php echo e(old('correo')); ?>">
            <?php $__errorArgs = ['correo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small>*<?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </label>
        <br>

        <label class="form-label" for="contraseña">
            Contraseña
            <input class="form-control shadow" type="password" name="contraseña" id="contraseña" placeholder="*************" value="<?php echo e(old('contraseña')); ?>">
            <?php $__errorArgs = ['contraseña'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small>*<?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </label>
        <br>

        <label class="form-label">
            <button class="btn btn-success shadow-lg" type="submit">
                Guardar
            </button>
         </label>
        <a href="<?php echo e(route('user.index')); ?>" class="btn btn-secondary shadow-lg">Cancelar</a>
    </form>
    
 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\app-practica\resources\views/usuarios/create.blade.php ENDPATH**/ ?>