
<?php $__env->startSection('titulo','Usuarios'); ?>

<?php $__env->startSection('contenido'); ?>
    <h1 class="text-center">
        Vista usuarios
    </h1>
    <a href="<?php echo e(route('user.create')); ?>" class="btn btn-primary mb-3 shadow-lg">Nuevo Usuario</a>
    <a href="<?php echo e(route('user.export')); ?>" class="btn btn-secondary mb-3 shadow-lg exportar"> Exportar Excel</a>
    <table class="table table-bordered table-hover shadow-lg">
        <thead class="table-dark">
            <tr>
                <th>
                    Id
                </th>
                <th>
                    Nombre
                </th>
                <th>
                    Correo Electronico
                </th>
                <th>
                    Opciones
                </th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th>
                        <?php echo e($usuario->id); ?>

                    </th>
                    <td>
                        <a href="<?php echo e(route('user.show',$usuario)); ?>"><?php echo e($usuario->name); ?></a>
                        
                    </td>
                    <td>
                        <?php echo e($usuario->email); ?>

                    </td>
                    <td>
                        <form action="<?php echo e(route('user.destroy',$usuario)); ?>" class="eliminar-usuario" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('Delete'); ?>
                            <a href="<?php echo e(route('user.edit',$usuario)); ?>" class="btn btn-success">Editar</a>
                            <button class="btn btn-danger" type="submit"> Eliminar </button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
        <!-- Para paginar vista -->
    <div class="d-flex justify-content-center">
        <?php echo e($usuarios->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <?php if(session('mensaje')=='OK'): ?>
        <script>
            Swal.fire(
                    '¡Borrado!',
                    'El usuario se ha eliminado.',
                    'success'
                    )
        </script>
    <?php endif; ?>

    <script>
        $('.eliminar-usuario').submit(function(e){
            e.preventDefault();
            Swal.fire({
                title: '¿Estás seguro?',
                text: "¡No podrás revertir esto!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Si, Eliminar!',
                cancelButtonText: 'Cancelar'
                }).then((result) => {
                if (result.isConfirmed) {
                    this.submit();
                }
             })
        });

        $('.exportar').click(function(e){
            Swal.fire({
                position: 'center',
                icon: 'success',
                title: 'La tabla usuarios se ha descargado correctamente',
                showConfirmButton: false,
                timer: 3000
            })
        });
        
    </script>  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\app-practica\resources\views/usuarios/index.blade.php ENDPATH**/ ?>