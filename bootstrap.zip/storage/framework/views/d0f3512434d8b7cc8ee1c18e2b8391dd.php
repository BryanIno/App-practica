<header>
    <nav class="navbar navbar-danger bg-danger shadow-lg ">
        <ul class="list-inline ">
            <li class="h1 list-inline-item mx-5 ">
                <a class="text-white nav-link " href="<?php echo e(route('home')); ?>"> Inicio</a>
            </li>
            <li class="h1 list-inline-item mx-5">
                <a class="text-white nav-link" href="<?php echo e(route('user.index')); ?>">Registro de Usuarios</a>
            </li>
            <li class="h1 list-inline-item mx-5" >
                <a class="text-white nav-link" href="<?php echo e(route('user.grafico')); ?>" >Grafico de Usuarios</a>
            </li>
        </ul>
    </nav>
</header>

<?php /**PATH C:\laragon\www\app-practica\resources\views/layouts/partials/header.blade.php ENDPATH**/ ?>