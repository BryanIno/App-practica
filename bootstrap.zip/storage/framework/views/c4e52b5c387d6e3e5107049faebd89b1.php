<table >
    <thead>
        <tr>
            <th>
                Id
            </th>
            <th>
                Nombre
            </th>
            <th>
                Correo Electronico
            </th>
        </tr>
    </thead>
   
    <tbody> 
        <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th>
                    <?php echo e($usuario->id); ?>

                </th>
                <td>
                    <?php echo e($usuario->name); ?>

                </td>
                <td>
                    <?php echo e($usuario->email); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
   
   
</table><?php /**PATH C:\laragon\www\app-practica\resources\views/usuarios/export.blade.php ENDPATH**/ ?>