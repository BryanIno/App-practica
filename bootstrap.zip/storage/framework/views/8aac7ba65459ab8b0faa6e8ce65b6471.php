
<?php $__env->startSection('titulo','Crear Usuario'); ?>

<?php $__env->startSection('contenido'); ?>
    <h1>
        Crear Usuario
    </h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\app-practica\resources\views/user/create.blade.php ENDPATH**/ ?>